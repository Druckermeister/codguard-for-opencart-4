<?php
/**
 * CodGuard for OpenCart - Catalog Language File (English)
 *
 * @package    CodGuard
 * @author     CodGuard
 * @copyright  2025 CodGuard
 * @license    GPL v2 or later
 * @version    1.0.0
 */

// Error messages
$_['error_rating_low'] = 'Unfortunately, we cannot offer Cash on Delivery for this order. Please select an alternative payment method.';
