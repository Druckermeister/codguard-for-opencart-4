<?php

/**
 * CodGuard for OpenCart 4.x - Catalog Controller
 *
 * @package    CodGuard
 * @author     CodGuard
 * @copyright  2025 CodGuard
 * @license    GPL v2 or later
 * @version    2.5.5
 */

namespace Opencart\Catalog\Controller\Extension\Codguard\Fraud;

class Codguard extends \Opencart\System\Engine\Controller
{
    /**
     * Add CodGuard JavaScript to checkout pages
     * Event: catalog/view (all pages, filtered for checkout)
     */
    public function addJavaScript(string &$route, array &$data, mixed &$output): void
    {
        // Only add on checkout pages
        if (strpos($route, 'checkout') === false) {
            return;
        }

        // Check if module is enabled
        if (!$this->config->get('module_codguard_status')) {
            return;
        }

        $this->log->write('CodGuard [DEBUG]: Adding JavaScript to checkout page - Route: ' . $route);

        // Add JavaScript file
        $this->document->addScript('catalog/view/javascript/codguard.js');
    }

    /**
     * Filter payment methods based on customer rating
     * Event: catalog/model/checkout/payment_method/getMethods/after
     *
     * This is the PRIMARY validation mechanism - it prevents COD from appearing
     * in the payment method list for low-rated customers.
     *
     * Triggered when: Payment method page is loading (after "Continue" from Delivery Method)
     */
    public function filterPaymentMethods(string &$route, array &$args, mixed &$output): void
    {
        $this->log->write('========================================');
        $this->log->write('CodGuard [DEBUG]: filterPaymentMethods() EVENT FIRED!');
        $this->log->write('CodGuard [DEBUG]: This fires when payment methods are being loaded');
        $this->log->write('========================================');

        // Check if module is enabled
        if (!$this->config->get('module_codguard_status')) {
            $this->log->write('CodGuard [INFO]: Module disabled, skipping payment method filter');
            return;
        }

        // Get configured COD methods
        $cod_methods = $this->config->get('module_codguard_cod_methods');
        if (!$cod_methods) {
            $this->log->write('CodGuard [INFO]: No COD methods configured, skipping filter');
            return;
        }

        $this->log->write('CodGuard [DEBUG]: Configured COD methods to potentially filter: ' . json_encode($cod_methods));

        // Get customer email
        $email = '';
        if (isset($this->session->data['customer']['email'])) {
            $email = $this->session->data['customer']['email'];
            $this->log->write('CodGuard [DEBUG]: Email from customer session: ' . $email);
        } elseif (isset($this->session->data['guest']['email'])) {
            $email = $this->session->data['guest']['email'];
            $this->log->write('CodGuard [DEBUG]: Email from guest session: ' . $email);
        } elseif ($this->customer->isLogged()) {
            $email = $this->customer->getEmail();
            $this->log->write('CodGuard [DEBUG]: Email from logged-in customer: ' . $email);
        }

        if (empty($email)) {
            $this->log->write('CodGuard [INFO]: No email found, cannot check rating - allowing all payment methods');
            return;
        }

        $this->log->write('CodGuard [INFO]: Checking customer rating for filtering - Email: ' . $email);

        $this->load->model('extension/codguard/fraud/codguard');

        // Get customer rating from API
        $rating = $this->model_extension_codguard_fraud_codguard->getCustomerRating($email);

        // If API failed, allow all methods (fail-open)
        if ($rating === null) {
            $this->log->write('CodGuard [WARNING]: API check failed for ' . $email . ', allowing all payment methods (fail-open)');
            return;
        }

        // Compare to tolerance
        $tolerance = (float)$this->config->get('module_codguard_rating_tolerance') / 100;
        $this->log->write('CodGuard [DEBUG]: Comparing rating ' . $rating . ' against tolerance ' . $tolerance);

        if ($rating < $tolerance) {
            // Customer rating is too low - remove COD payment methods from the list
            $this->log->write('CodGuard [WARNING]: Customer rating BELOW tolerance - FILTERING OUT COD methods');

            // Log the block event
            $this->model_extension_codguard_fraud_codguard->logBlockEvent(
                $email,
                $rating,
                $this->request->server['REMOTE_ADDR'] ?? ''
            );

            // Filter out COD methods from the output array
            // $output is the payment methods array returned by getMethods()
            foreach ($cod_methods as $cod_method) {
                if (isset($output[$cod_method])) {
                    $this->log->write('CodGuard [INFO]: REMOVED payment method: ' . $cod_method . ' (' . ($output[$cod_method]['name'] ?? 'unknown') . ')');
                    unset($output[$cod_method]);
                }

                // Also check for extension-prefixed versions (e.g., "cod.cod")
                foreach ($output as $key => $method) {
                    if (strpos($key, $cod_method . '.') === 0 || strpos($key, '.' . $cod_method) !== false) {
                        $this->log->write('CodGuard [INFO]: REMOVED payment method (pattern match): ' . $key . ' (' . ($method['name'] ?? 'unknown') . ')');
                        unset($output[$key]);
                    }
                }
            }

            $this->log->write('CodGuard [INFO]: Payment methods filtered - remaining count: ' . count($output));
        } else {
            $this->log->write('CodGuard [INFO]: Customer rating OK (' . $rating . ' >= ' . $tolerance . ') - allowing all payment methods including COD');
        }
    }

    /**
     * Event handler for order status changes
     * Called when order history is added (status change)
     */
    public function eventOrderStatusChange(string &$route, array &$args, mixed &$output): void
    {
        // Check if module is enabled
        if (!$this->config->get('module_codguard_status')) {
            return;
        }

        // Get order ID and new status from arguments
        $order_id = $args[0];
        $order_status_id = $args[1];

        $this->load->model('extension/codguard/fraud/codguard');
        $this->model_extension_codguard_fraud_codguard->queueOrder($order_id, $order_status_id);
    }

    /**
     * Validate customer rating during checkout
     * Called via AJAX from checkout page
     */
    public function validateRating(): void
    {
        $json = array();

        $this->log->write('CodGuard [DEBUG]: validateRating() called');
        $this->log->write('CodGuard [DEBUG]: POST data: ' . json_encode($this->request->post));

        // Check if module is enabled
        $module_status = $this->config->get('module_codguard_status');
        $this->log->write('CodGuard [DEBUG]: Module status: ' . ($module_status ? 'ENABLED' : 'DISABLED'));

        if (!$module_status) {
            $json['success'] = true;
            $json['message'] = 'Module disabled';
            $this->log->write('CodGuard [INFO]: Validation skipped - module disabled');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }

        // Get email from request
        $email = isset($this->request->post['email']) ? $this->request->post['email'] : '';
        $payment_method = isset($this->request->post['payment_method']) ? $this->request->post['payment_method'] : '';

        $this->log->write('CodGuard [DEBUG]: Email: ' . $email);
        $this->log->write('CodGuard [DEBUG]: Payment method: ' . $payment_method);

        if (empty($email)) {
            $json['success'] = true;
            $json['message'] = 'No email provided';
            $this->log->write('CodGuard [INFO]: Validation skipped - no email provided');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }

        // Check if payment method is a COD method - handle both "cod" and "cod.cod" patterns
        $cod_methods = $this->config->get('module_codguard_cod_methods');
        $this->log->write('CodGuard [DEBUG]: Configured COD methods: ' . ($cod_methods ? json_encode($cod_methods) : 'NONE'));

        $is_cod = false;
        if ($cod_methods) {
            // Check exact match first
            if (in_array($payment_method, $cod_methods)) {
                $is_cod = true;
            } else {
                // Check if payment code contains any configured COD method
                foreach ($cod_methods as $method) {
                    if (strpos($payment_method, $method) === 0 || strpos($payment_method, $method . '.') !== false) {
                        $is_cod = true;
                        $this->log->write('CodGuard [DEBUG]: Pattern match: "' . $payment_method . '" contains "' . $method . '"');
                        break;
                    }
                }
            }
        }

        if (!$is_cod) {
            $json['success'] = true;
            $json['message'] = 'Not a COD payment method';
            $this->log->write('CodGuard [INFO]: Validation skipped - payment method "' . $payment_method . '" is not in COD methods list');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }

        $this->log->write('CodGuard [INFO]: Starting rating validation for COD payment - Email: ' . $email . ', Method: ' . $payment_method);

        $this->load->model('extension/codguard/fraud/codguard');
        $this->load->language('extension/codguard/fraud/codguard');

        // Get customer rating
        $rating = $this->model_extension_codguard_fraud_codguard->getCustomerRating($email);

        // If API failed, allow (fail-open)
        if ($rating === null) {
            $json['success'] = true;
            $json['message'] = 'API check failed, allowing checkout';
            $this->log->write('CodGuard [WARNING]: API check failed for ' . $email . ', allowing checkout (fail-open)');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }

        // Compare to tolerance
        $tolerance = (float)$this->config->get('module_codguard_rating_tolerance') / 100;
        $this->log->write('CodGuard [DEBUG]: Comparing rating ' . $rating . ' against tolerance ' . $tolerance);

        if ($rating < $tolerance) {
            // Block COD
            $this->model_extension_codguard_fraud_codguard->logBlockEvent(
                $email,
                $rating,
                $this->request->server['REMOTE_ADDR']
            );

            $json['success'] = false;
            $json['error'] = $this->config->get('module_codguard_rejection_message') ?: $this->language->get('error_rating_low');
            $this->log->write('CodGuard [WARNING]: BLOCKED COD payment - Email: ' . $email . ', Rating: ' . $rating . ' < Tolerance: ' . $tolerance);
        } else {
            $json['success'] = true;
            $json['message'] = 'Rating OK';
            $this->log->write('CodGuard [INFO]: ALLOWED COD payment - Email: ' . $email . ', Rating: ' . $rating . ' >= Tolerance: ' . $tolerance);
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    /**
     * Validate when payment method is selected (controller level)
     * Event: catalog/controller/checkout/payment_method.save/before
     */
    public function validatePaymentMethodController(string &$route, array &$data): void
    {
        $this->log->write('========================================');
        $this->log->write('CodGuard [DEBUG]: validatePaymentMethodController() EVENT FIRED!');
        $this->log->write('CodGuard [DEBUG]: POST data: ' . json_encode($this->request->post));
        $this->log->write('========================================');

        // Check if module is enabled
        if (!$this->config->get('module_codguard_status')) {
            return;
        }

        // Get payment method code from POST
        $payment_code = $this->request->post['payment_method'] ?? '';
        if (empty($payment_code)) {
            $this->log->write('CodGuard [INFO]: No payment method in POST');
            return;
        }

        $this->log->write('CodGuard [DEBUG]: Payment method from POST: ' . $payment_code);

        // Check if it's a COD method
        $cod_methods = $this->config->get('module_codguard_cod_methods');
        $this->log->write('CodGuard [DEBUG]: Configured COD methods: ' . ($cod_methods ? json_encode($cod_methods) : 'NONE'));

        $is_cod = false;
        if ($cod_methods) {
            if (in_array($payment_code, $cod_methods)) {
                $is_cod = true;
            } else {
                foreach ($cod_methods as $method) {
                    if (strpos($payment_code, $method) === 0 || strpos($payment_code, $method . '.') !== false) {
                        $is_cod = true;
                        $this->log->write('CodGuard [DEBUG]: Pattern match: "' . $payment_code . '" contains "' . $method . '"');
                        break;
                    }
                }
            }
        }

        if (!$is_cod) {
            $this->log->write('CodGuard [INFO]: Not a COD payment method');
            return;
        }

        // Get customer email - try multiple session locations
        $email = '';

        // Try guest session
        if (isset($this->session->data['guest']['email'])) {
            $email = $this->session->data['guest']['email'];
            $this->log->write('CodGuard [DEBUG]: Email from guest session: ' . $email);
        }
        // Try logged-in customer
        elseif ($this->customer->isLogged()) {
            $email = $this->customer->getEmail();
            $this->log->write('CodGuard [DEBUG]: Email from logged-in customer: ' . $email);
        }
        // Try order data in session
        elseif (isset($this->session->data['order']['email'])) {
            $email = $this->session->data['order']['email'];
            $this->log->write('CodGuard [DEBUG]: Email from order session: ' . $email);
        }
        // Try customer data in session
        elseif (isset($this->session->data['customer']['email'])) {
            $email = $this->session->data['customer']['email'];
            $this->log->write('CodGuard [DEBUG]: Email from customer session: ' . $email);
        }
        // Try POST data (might be sent with payment method)
        elseif (isset($this->request->post['email'])) {
            $email = $this->request->post['email'];
            $this->log->write('CodGuard [DEBUG]: Email from POST data: ' . $email);
        }

        // Debug: Log all session keys to find where email is stored
        if (empty($email)) {
            $this->log->write('CodGuard [DEBUG]: No email found. Session keys: ' . implode(', ', array_keys($this->session->data)));
            if (isset($this->session->data['guest'])) {
                $this->log->write('CodGuard [DEBUG]: Guest session keys: ' . implode(', ', array_keys($this->session->data['guest'])));
            }
            if (isset($this->session->data['order'])) {
                $this->log->write('CodGuard [DEBUG]: Order session keys: ' . implode(', ', array_keys($this->session->data['order'])));
            }
            $this->log->write('CodGuard [INFO]: No email found - cannot validate at this point');
            return;
        }

        $this->log->write('CodGuard [INFO]: Validating COD payment selection (controller) - Email: ' . $email . ', Method: ' . $payment_code);

        $this->load->model('extension/codguard/fraud/codguard');
        $this->load->language('extension/codguard/fraud/codguard');

        // Get customer rating from API
        $rating = $this->model_extension_codguard_fraud_codguard->getCustomerRating($email);

        // If API failed, allow (fail-open)
        if ($rating === null) {
            $this->log->write('CodGuard [WARNING]: API failed, allowing payment method (fail-open)');
            return;
        }

        // Compare to tolerance
        $tolerance = (float)$this->config->get('module_codguard_rating_tolerance') / 100;
        $this->log->write('CodGuard [DEBUG]: Rating: ' . $rating . ', Tolerance: ' . $tolerance);

        if ($rating < $tolerance) {
            // Block COD payment method
            $this->model_extension_codguard_fraud_codguard->logBlockEvent(
                $email,
                $rating,
                $this->request->server['REMOTE_ADDR'] ?? ''
            );

            $this->log->write('CodGuard [WARNING]: BLOCKING COD payment method - Rating: ' . $rating . ' < Tolerance: ' . $tolerance);

            // Set error in response - OpenCart will handle displaying it
            $error_message = $this->config->get('module_codguard_rejection_message') ?: $this->language->get('error_rating_low');

            // Store error in session for display
            $this->session->data['codguard_error'] = $error_message;

            // Throw exception to prevent payment method from being saved
            throw new \Exception($error_message);
        } else {
            $this->log->write('CodGuard [INFO]: ALLOWING COD payment method - Rating: ' . $rating . ' >= Tolerance: ' . $tolerance);
        }
    }

    /**
     * Validate when payment method is selected (model level)
     * Event: catalog/model/checkout/payment_method/setPaymentMethod/before
     */
    public function validatePaymentMethod(string &$route, array &$args, mixed &$output): void
    {
        $this->log->write('========================================');
        $this->log->write('CodGuard [DEBUG]: validatePaymentMethod() EVENT FIRED!');
        $this->log->write('CodGuard [DEBUG]: Args: ' . json_encode($args));
        $this->log->write('========================================');

        // Check if module is enabled
        if (!$this->config->get('module_codguard_status')) {
            return;
        }

        // Get payment method code from args
        $payment_method = $args[0] ?? null;
        if (!$payment_method) {
            $this->log->write('CodGuard [INFO]: No payment method in args');
            return;
        }

        // Extract payment code
        $payment_code = '';
        if (is_array($payment_method)) {
            $payment_code = $payment_method['code'] ?? '';
            $this->log->write('CodGuard [DEBUG]: Payment method (array): ' . json_encode($payment_method));
        } else {
            $payment_code = $payment_method;
            $this->log->write('CodGuard [DEBUG]: Payment method (string): ' . $payment_method);
        }

        if (empty($payment_code)) {
            $this->log->write('CodGuard [INFO]: No payment code found');
            return;
        }

        // Check if it's a COD method
        $cod_methods = $this->config->get('module_codguard_cod_methods');
        $this->log->write('CodGuard [DEBUG]: Configured COD methods: ' . ($cod_methods ? json_encode($cod_methods) : 'NONE'));

        $is_cod = false;
        if ($cod_methods) {
            if (in_array($payment_code, $cod_methods)) {
                $is_cod = true;
            } else {
                foreach ($cod_methods as $method) {
                    if (strpos($payment_code, $method) === 0 || strpos($payment_code, $method . '.') !== false) {
                        $is_cod = true;
                        $this->log->write('CodGuard [DEBUG]: Pattern match: "' . $payment_code . '" contains "' . $method . '"');
                        break;
                    }
                }
            }
        }

        if (!$is_cod) {
            $this->log->write('CodGuard [INFO]: Not a COD payment method');
            return;
        }

        // Get customer email
        $email = '';
        if (isset($this->session->data['guest']['email'])) {
            $email = $this->session->data['guest']['email'];
        } elseif ($this->customer->isLogged()) {
            $email = $this->customer->getEmail();
        }

        if (empty($email)) {
            $this->log->write('CodGuard [INFO]: No email found - cannot validate');
            return;
        }

        $this->log->write('CodGuard [INFO]: Validating COD payment selection - Email: ' . $email . ', Method: ' . $payment_code);

        $this->load->model('extension/codguard/fraud/codguard');
        $this->load->language('extension/codguard/fraud/codguard');

        // Get customer rating from API
        $rating = $this->model_extension_codguard_fraud_codguard->getCustomerRating($email);

        // If API failed, allow (fail-open)
        if ($rating === null) {
            $this->log->write('CodGuard [WARNING]: API failed, allowing payment method (fail-open)');
            return;
        }

        // Compare to tolerance
        $tolerance = (float)$this->config->get('module_codguard_rating_tolerance') / 100;
        $this->log->write('CodGuard [DEBUG]: Rating: ' . $rating . ', Tolerance: ' . $tolerance);

        if ($rating < $tolerance) {
            // Block COD payment method
            $this->model_extension_codguard_fraud_codguard->logBlockEvent(
                $email,
                $rating,
                $this->request->server['REMOTE_ADDR'] ?? ''
            );

            $this->log->write('CodGuard [WARNING]: BLOCKING COD payment method - Rating: ' . $rating . ' < Tolerance: ' . $tolerance);

            // Throw exception to prevent payment method from being saved
            $error_message = $this->config->get('module_codguard_rejection_message') ?: $this->language->get('error_rating_low');
            throw new \Exception($error_message);
        } else {
            $this->log->write('CodGuard [INFO]: ALLOWING COD payment method - Rating: ' . $rating . ' >= Tolerance: ' . $tolerance);
        }
    }

    /**
     * Server-side checkout validation
     * Called before order is created in database
     * Event: catalog/model/checkout/order/addOrder/before
     */
    public function validateCheckout(string &$route, array &$args, mixed &$output): void
    {
        // Log with timestamp and all details
        $this->log->write('========================================');
        $this->log->write('CodGuard [DEBUG]: validateCheckout() EVENT FIRED!');
        $this->log->write('CodGuard [DEBUG]: Timestamp: ' . date('Y-m-d H:i:s'));
        $this->log->write('CodGuard [DEBUG]: Route: ' . $route);
        $this->log->write('CodGuard [DEBUG]: Args count: ' . count($args));
        $this->log->write('CodGuard [DEBUG]: Args keys: ' . json_encode(array_keys($args)));
        $this->log->write('========================================');

        // Check if module is enabled
        $module_status = $this->config->get('module_codguard_status');
        $this->log->write('CodGuard [DEBUG]: Module status: ' . ($module_status ? 'ENABLED' : 'DISABLED'));

        if (!$module_status) {
            $this->log->write('CodGuard [INFO]: Checkout validation skipped - module disabled');
            return;
        }

        // Debug: Log session payment method data
        $session_payment_info = isset($this->session->data['payment_method']) ?
            json_encode($this->session->data['payment_method']) : 'NOT SET';
        $this->log->write('CodGuard [DEBUG]: Session payment_method data: ' . $session_payment_info);

        // Debug: Log POST payment method
        $post_payment = isset($this->request->post['payment_method']) ?
            $this->request->post['payment_method'] : 'NOT SET';
        $this->log->write('CodGuard [DEBUG]: POST payment_method: ' . $post_payment);

        // Get payment method from session or POST data
        $payment_code = '';

        // Try session first
        if (isset($this->session->data['payment_method']['code'])) {
            $payment_code = $this->session->data['payment_method']['code'];
            $this->log->write('CodGuard [DEBUG]: Using payment method from session: ' . $payment_code);
        }
        // Fallback to POST data (for OpenCart 4.x checkout flow)
        elseif (isset($this->request->post['payment_method'])) {
            $payment_code = $this->request->post['payment_method'];
            $this->log->write('CodGuard [DEBUG]: Using payment method from POST data: ' . $payment_code);
        }

        // If still no payment method, skip validation
        if (empty($payment_code)) {
            $this->log->write('CodGuard [INFO]: Checkout validation skipped - no payment method available (this is normal if AJAX validation already ran)');
            return;
        }

        // Check if it's a COD method - handle both "cod" and "cod.cod" patterns
        $cod_methods = $this->config->get('module_codguard_cod_methods');
        $this->log->write('CodGuard [DEBUG]: Configured COD methods: ' . ($cod_methods ? json_encode($cod_methods) : 'NONE'));

        $is_cod = false;
        if ($cod_methods) {
            // Check exact match first
            if (in_array($payment_code, $cod_methods)) {
                $is_cod = true;
            } else {
                // Check if payment code contains any configured COD method
                foreach ($cod_methods as $method) {
                    if (strpos($payment_code, $method) === 0 || strpos($payment_code, $method . '.') !== false) {
                        $is_cod = true;
                        $this->log->write('CodGuard [DEBUG]: Pattern match: "' . $payment_code . '" contains "' . $method . '"');
                        break;
                    }
                }
            }
        }

        if (!$is_cod) {
            $this->log->write('CodGuard [INFO]: Checkout validation skipped - payment method "' . $payment_code . '" is not in COD methods list');
            return;
        }

        // Get customer email
        $email = '';
        if (isset($this->session->data['guest']['email'])) {
            $email = $this->session->data['guest']['email'];
            $this->log->write('CodGuard [DEBUG]: Email from guest session: ' . $email);
        } elseif ($this->customer->isLogged()) {
            $email = $this->customer->getEmail();
            $this->log->write('CodGuard [DEBUG]: Email from logged-in customer: ' . $email);
        }

        if (empty($email)) {
            $this->log->write('CodGuard [INFO]: Checkout validation skipped - no email found');
            return;
        }

        $this->log->write('CodGuard [INFO]: Starting server-side checkout validation for COD - Email: ' . $email . ', Method: ' . $payment_code);

        $this->load->model('extension/codguard/fraud/codguard');
        $this->load->language('extension/codguard/fraud/codguard');

        // Get customer rating from API
        $rating = $this->model_extension_codguard_fraud_codguard->getCustomerRating($email);

        // If API failed, allow (fail-open)
        if ($rating === null) {
            $this->log->write('CodGuard [WARNING]: API failed for ' . $email . ', allowing order (fail-open)');
            return;
        }

        // Compare to tolerance
        $tolerance = (float)$this->config->get('module_codguard_rating_tolerance') / 100;
        $this->log->write('CodGuard [DEBUG]: Comparing rating ' . $rating . ' against tolerance ' . $tolerance);

        if ($rating < $tolerance) {
            // Block the order
            $this->model_extension_codguard_fraud_codguard->logBlockEvent(
                $email,
                $rating,
                $this->request->server['REMOTE_ADDR'] ?? ''
            );

            $error_message = $this->config->get('module_codguard_rejection_message') ?: $this->language->get('error_rating_low');

            $this->log->write('CodGuard [WARNING]: BLOCKED checkout - Email: ' . $email . ', Rating: ' . $rating . ' < Tolerance: ' . $tolerance);

            // Set error in session and redirect
            $this->session->data['error'] = $error_message;
            $this->response->redirect($this->url->link('checkout/checkout', '', true));
        } else {
            $this->log->write('CodGuard [INFO]: ALLOWED checkout - Email: ' . $email . ', Rating: ' . $rating . ' >= Tolerance: ' . $tolerance);
        }
    }

    /**
     * Fallback validation using controller event (earlier in checkout flow)
     * Event: catalog/controller/checkout/confirm/before
     *
     * This fires reliably in OpenCart 4.1, so we do the actual validation here
     */
    public function validateCheckoutConfirm(string &$route, array &$data): void
    {
        $this->log->write('========================================');
        $this->log->write('CodGuard [DEBUG]: validateCheckoutConfirm() FALLBACK EVENT FIRED!');
        $this->log->write('CodGuard [DEBUG]: Request method: ' . ($this->request->server['REQUEST_METHOD'] ?? 'UNKNOWN'));
        $this->log->write('CodGuard [DEBUG]: Is AJAX: ' . (isset($this->request->server['HTTP_X_REQUESTED_WITH']) ? 'YES' : 'NO'));
        $this->log->write('CodGuard [DEBUG]: Starting server-side validation');
        $this->log->write('========================================');

        // Check if module is enabled
        $module_status = $this->config->get('module_codguard_status');
        $this->log->write('CodGuard [DEBUG]: Module status: ' . ($module_status ? 'ENABLED' : 'DISABLED'));

        if (!$module_status) {
            $this->log->write('CodGuard [INFO]: Validation skipped - module disabled');
            return;
        }

        // Debug: Log session payment method data
        $session_payment_info = isset($this->session->data['payment_method']) ?
            json_encode($this->session->data['payment_method']) : 'NOT SET';
        $this->log->write('CodGuard [DEBUG]: Session payment_method data: ' . $session_payment_info);

        // Debug: Log POST payment method
        $post_payment = isset($this->request->post['payment_method']) ?
            $this->request->post['payment_method'] : 'NOT SET';
        $this->log->write('CodGuard [DEBUG]: POST payment_method: ' . $post_payment);

        // Get payment method from session or POST data
        $payment_code = '';

        // Try session first
        if (isset($this->session->data['payment_method']['code'])) {
            $payment_code = $this->session->data['payment_method']['code'];
            $this->log->write('CodGuard [DEBUG]: Using payment method from session: ' . $payment_code);
        }
        // Fallback to POST data
        elseif (isset($this->request->post['payment_method'])) {
            $payment_code = $this->request->post['payment_method'];
            $this->log->write('CodGuard [DEBUG]: Using payment method from POST data: ' . $payment_code);
        }

        // If still no payment method, skip validation UNLESS this is a POST request (actual submit)
        if (empty($payment_code)) {
            $request_method = $this->request->server['REQUEST_METHOD'] ?? 'GET';
            if ($request_method === 'POST') {
                $this->log->write('CodGuard [WARNING]: POST request but no payment method found! Checking order session...');

                // Last resort: check if there's an order being created
                if (isset($this->session->data['order_id'])) {
                    $this->log->write('CodGuard [DEBUG]: Order ID in session: ' . $this->session->data['order_id']);
                }
            } else {
                $this->log->write('CodGuard [INFO]: Validation skipped - no payment method available yet (GET request)');
            }
            return;
        }

        // Check if it's a COD method - handle both "cod" and "cod.cod" patterns
        $cod_methods = $this->config->get('module_codguard_cod_methods');
        $this->log->write('CodGuard [DEBUG]: Configured COD methods: ' . ($cod_methods ? json_encode($cod_methods) : 'NONE'));

        $is_cod = false;
        if ($cod_methods) {
            // Check exact match first
            if (in_array($payment_code, $cod_methods)) {
                $is_cod = true;
            } else {
                // Check if payment code contains any configured COD method
                foreach ($cod_methods as $method) {
                    if (strpos($payment_code, $method) === 0 || strpos($payment_code, $method . '.') !== false) {
                        $is_cod = true;
                        $this->log->write('CodGuard [DEBUG]: Pattern match: "' . $payment_code . '" contains "' . $method . '"');
                        break;
                    }
                }
            }
        }

        if (!$is_cod) {
            $this->log->write('CodGuard [INFO]: Validation skipped - payment method "' . $payment_code . '" is not in COD methods list');
            return;
        }

        // Get customer email
        $email = '';
        if (isset($this->session->data['guest']['email'])) {
            $email = $this->session->data['guest']['email'];
            $this->log->write('CodGuard [DEBUG]: Email from guest session: ' . $email);
        } elseif ($this->customer->isLogged()) {
            $email = $this->customer->getEmail();
            $this->log->write('CodGuard [DEBUG]: Email from logged-in customer: ' . $email);
        }

        if (empty($email)) {
            $this->log->write('CodGuard [INFO]: Validation skipped - no email found');
            return;
        }

        $this->log->write('CodGuard [INFO]: Starting server-side validation for COD - Email: ' . $email . ', Method: ' . $payment_code);

        $this->load->model('extension/codguard/fraud/codguard');
        $this->load->language('extension/codguard/fraud/codguard');

        // Get customer rating from API
        $rating = $this->model_extension_codguard_fraud_codguard->getCustomerRating($email);

        // If API failed, allow (fail-open)
        if ($rating === null) {
            $this->log->write('CodGuard [WARNING]: API failed for ' . $email . ', allowing order (fail-open)');
            return;
        }

        // Compare to tolerance
        $tolerance = (float)$this->config->get('module_codguard_rating_tolerance') / 100;
        $this->log->write('CodGuard [DEBUG]: Comparing rating ' . $rating . ' against tolerance ' . $tolerance);

        if ($rating < $tolerance) {
            // Block the order
            $this->model_extension_codguard_fraud_codguard->logBlockEvent(
                $email,
                $rating,
                $this->request->server['REMOTE_ADDR'] ?? ''
            );

            $error_message = $this->config->get('module_codguard_rejection_message') ?: $this->language->get('error_rating_low');

            $this->log->write('CodGuard [WARNING]: BLOCKED checkout - Email: ' . $email . ', Rating: ' . $rating . ' < Tolerance: ' . $tolerance);

            // Set error in session and redirect
            $this->session->data['error'] = $error_message;
            $this->response->redirect($this->url->link('checkout/checkout', '', true));
        } else {
            $this->log->write('CodGuard [INFO]: ALLOWED checkout - Email: ' . $email . ', Rating: ' . $rating . ' >= Tolerance: ' . $tolerance);
        }
    }

    /**
     * Post-order validation (after order is created)
     * Event: catalog/controller/checkout/success/before
     *
     * This is a last resort - order is already created, but we can log and potentially cancel it
     */
    public function validateAfterOrder(string &$route, array &$data): void
    {
        $this->log->write('========================================');
        $this->log->write('CodGuard [WARNING]: validateAfterOrder() called - ORDER ALREADY CREATED!');
        $this->log->write('CodGuard [WARNING]: This means validation happened too late!');

        // Check if there's an order_id in session
        if (isset($this->session->data['order_id'])) {
            $order_id = $this->session->data['order_id'];
            $this->log->write('CodGuard [INFO]: Order ID from session: ' . $order_id);

            // Load order details
            $this->load->model('checkout/order');
            $order_info = $this->model_checkout_order->getOrder($order_id);

            if ($order_info) {
                $this->log->write('CodGuard [INFO]: Order email: ' . $order_info['email']);
                $this->log->write('CodGuard [DEBUG]: Order info keys: ' . implode(', ', array_keys($order_info)));

                // Payment method might be an array or string
                if (is_array($order_info['payment_method'])) {
                    $this->log->write('CodGuard [INFO]: Payment method (array): ' . json_encode($order_info['payment_method']));
                    $payment_code = $order_info['payment_method']['code'] ?? $order_info['payment_method'][0] ?? '';
                } else {
                    $this->log->write('CodGuard [INFO]: Payment method: ' . $order_info['payment_method']);
                    $payment_code = $order_info['payment_method'];
                }

                // Also check payment_code key directly
                if (isset($order_info['payment_code'])) {
                    $payment_code = $order_info['payment_code'];
                }

                $this->log->write('CodGuard [INFO]: Payment code extracted: ' . $payment_code);

                // Check if COD - handle both "cod" and "cod.cod" patterns
                $cod_methods = $this->config->get('module_codguard_cod_methods');
                $this->log->write('CodGuard [DEBUG]: Configured COD methods: ' . ($cod_methods ? json_encode($cod_methods) : 'NONE'));

                $is_cod = false;
                if ($cod_methods) {
                    // Check exact match first
                    if (in_array($payment_code, $cod_methods)) {
                        $is_cod = true;
                        $this->log->write('CodGuard [DEBUG]: Exact match found for payment code');
                    } else {
                        // Check if payment code starts with any configured COD method
                        foreach ($cod_methods as $method) {
                            if (strpos($payment_code, $method) === 0 || strpos($payment_code, $method . '.') !== false) {
                                $is_cod = true;
                                $this->log->write('CodGuard [DEBUG]: Pattern match found: "' . $payment_code . '" contains "' . $method . '"');
                                break;
                            }
                        }
                    }
                }

                if ($is_cod) {
                    $this->log->write('CodGuard [WARNING]: This was a COD order that should have been validated!');

                    // We can still check the rating and log a warning
                    $this->load->model('extension/codguard/fraud/codguard');
                    $rating = $this->model_extension_codguard_fraud_codguard->getCustomerRating($order_info['email']);

                    if ($rating !== null) {
                        $tolerance = (float)$this->config->get('module_codguard_rating_tolerance') / 100;
                        $this->log->write('CodGuard [INFO]: Customer rating: ' . $rating . ', Tolerance: ' . $tolerance);

                        if ($rating < $tolerance) {
                            $this->log->write('CodGuard [CRITICAL]: Order #' . $order_id . ' SHOULD HAVE BEEN BLOCKED! Rating: ' . $rating);
                            $this->log->write('CodGuard [WARNING]: This order went through because validation could not happen before order creation');
                        }
                    }
                }
            }
        }

        $this->log->write('========================================');
    }

    /**
     * Test endpoint to verify event can be triggered
     * Access via: index.php?route=extension/codguard/fraud/codguard.testEvent
     */
    public function testEvent(): void
    {
        $this->log->write('CodGuard [TEST]: testEvent() called - this proves the controller is accessible');

        $route = 'test/route';
        $args = array('test' => 'data');
        $output = null;

        $this->log->write('CodGuard [TEST]: Calling validateCheckout() directly...');
        $this->validateCheckout($route, $args, $output);
        $this->log->write('CodGuard [TEST]: validateCheckout() call completed');

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode(array(
            'success' => true,
            'message' => 'Test completed - check error log for results'
        )));
    }

    /**
     * Debug test endpoint to manually test API connection
     * Access via: index.php?route=extension/codguard/fraud/codguard.testApi&email=test@example.com
     */
    public function testApi(): void
    {
        // Only allow in development/testing
        $email = isset($this->request->get['email']) ? $this->request->get['email'] : 'test@example.com';

        $this->log->write('CodGuard [TEST]: Manual API test initiated for email: ' . $email);

        $this->load->model('extension/codguard/fraud/codguard');

        $shop_id = $this->config->get('module_codguard_shop_id');
        $public_key = $this->config->get('module_codguard_public_key');
        $module_status = $this->config->get('module_codguard_status');
        $cod_methods = $this->config->get('module_codguard_cod_methods');
        $tolerance = $this->config->get('module_codguard_rating_tolerance');

        $output = array(
            'test_time' => date('Y-m-d H:i:s'),
            'email' => $email,
            'configuration' => array(
                'module_enabled' => $module_status ? 'YES' : 'NO',
                'shop_id' => $shop_id ?: 'NOT SET',
                'public_key' => $public_key ? substr($public_key, 0, 10) . '... (' . strlen($public_key) . ' chars)' : 'NOT SET',
                'cod_methods' => $cod_methods ? implode(', ', $cod_methods) : 'NONE',
                'rating_tolerance' => $tolerance . '%'
            ),
            'api_test' => array()
        );

        // Test API call
        $rating = $this->model_extension_codguard_fraud_codguard->getCustomerRating($email);

        if ($rating === null) {
            $output['api_test']['status'] = 'FAILED';
            $output['api_test']['message'] = 'API call failed - check error log for details';
        } else {
            $output['api_test']['status'] = 'SUCCESS';
            $output['api_test']['rating'] = $rating;
            $output['api_test']['tolerance'] = (float)$tolerance / 100;
            $output['api_test']['would_allow'] = $rating >= ((float)$tolerance / 100) ? 'YES' : 'NO';
        }

        $this->log->write('CodGuard [TEST]: Test results - ' . json_encode($output));

        // Output JSON response
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($output, JSON_PRETTY_PRINT));
    }

    /**
     * Filter payment methods at controller level (for OpenCart 4 compatibility)
     * Event: catalog/controller/checkout/payment_method.getMethods/after
     */
    public function filterPaymentMethodsController(string &$route, array &$args, mixed &$output): void
    {
        $this->log->write('========================================');
        $this->log->write('CodGuard [DEBUG]: filterPaymentMethodsController() EVENT FIRED!');
        $this->log->write('========================================');

        // Check if module is enabled
        if (!$this->config->get('module_codguard_status')) {
            $this->log->write('CodGuard [INFO]: Module disabled');
            return;
        }

        // Get configured COD methods
        $cod_methods = $this->config->get('module_codguard_cod_methods');
        if (!$cod_methods) {
            $this->log->write('CodGuard [INFO]: No COD methods configured');
            return;
        }

        $this->log->write('CodGuard [DEBUG]: COD methods: ' . json_encode($cod_methods));

        // Get customer email
        $email = '';
        if (isset($this->session->data['customer']['email'])) {
            $email = $this->session->data['customer']['email'];
            $this->log->write('CodGuard [DEBUG]: Email from customer session: ' . $email);
        } elseif (isset($this->session->data['guest']['email'])) {
            $email = $this->session->data['guest']['email'];
            $this->log->write('CodGuard [DEBUG]: Email from guest session: ' . $email);
        } elseif ($this->customer->isLogged()) {
            $email = $this->customer->getEmail();
            $this->log->write('CodGuard [DEBUG]: Email from logged customer: ' . $email);
        }

        if (empty($email)) {
            $this->log->write('CodGuard [INFO]: No email found');
            return;
        }

        $this->log->write('CodGuard [INFO]: Checking rating for: ' . $email);

        // Get customer rating
        $this->load->model('extension/codguard/fraud/codguard');
        $rating = $this->model_extension_codguard_fraud_codguard->getCustomerRating($email);

        if ($rating === null) {
            $this->log->write('CodGuard [WARNING]: API check failed, allowing all methods');
            return;
        }

        // Compare to tolerance
        $tolerance = (float)$this->config->get('module_codguard_rating_tolerance') / 100;
        $this->log->write('CodGuard [DEBUG]: Rating ' . $rating . ' vs tolerance ' . $tolerance);

        if ($rating < $tolerance) {
            $this->log->write('CodGuard [WARNING]: Rating BELOW tolerance - FILTERING COD');

            // Set flag for custom error message
            $this->session->data['codguard_blocked'] = true;

            // Log block event
            $this->model_extension_codguard_fraud_codguard->logBlockEvent(
                $email,
                $rating,
                $this->request->server['REMOTE_ADDR'] ?? ''
            );

            // Filter from session
            if (isset($this->session->data['payment_methods'])) {
                foreach ($cod_methods as $cod_method) {
                    if (isset($this->session->data['payment_methods'][$cod_method])) {
                        $this->log->write('CodGuard [INFO]: REMOVED from session: ' . $cod_method);
                        unset($this->session->data['payment_methods'][$cod_method]);
                    }
                }
            }

            // Also filter from the response output if it exists
            // The output is the response body that will be sent
            if (!empty($output)) {
                $response_body = $this->response->getOutput();
                if (!empty($response_body)) {
                    $json_data = json_decode($response_body, true);
                    if (isset($json_data['payment_methods'])) {
                        $this->log->write('CodGuard [DEBUG]: Filtering from JSON response');
                        foreach ($cod_methods as $cod_method) {
                            if (isset($json_data['payment_methods'][$cod_method])) {
                                $this->log->write('CodGuard [INFO]: REMOVED from JSON response: ' . $cod_method);
                                unset($json_data['payment_methods'][$cod_method]);
                            }
                        }
                        // Update the response
                        $this->response->setOutput(json_encode($json_data));
                        $this->log->write('CodGuard [DEBUG]: JSON response updated');
                    }
                }
            }
        } else {
            $this->log->write('CodGuard [INFO]: Rating OK - allowing COD');
        }
    }

    /**
     * Intercept payment method save to show custom rejection message
     * Event: catalog/controller/checkout/payment_method.save/after
     */
    /**
     * Intercept payment method save to validate and show custom rejection message
     * Event: catalog/controller/checkout/payment_method.save/after
     */
    public function interceptPaymentSave(string &$route, array &$args, mixed &$output): void
    {
        $this->log->write('========================================');
        $this->log->write('CodGuard [DEBUG]: interceptPaymentSave() EVENT FIRED!');
        $this->log->write('========================================');

        // Check if module is enabled
        if (!$this->config->get('module_codguard_status')) {
            $this->log->write('CodGuard [INFO]: Module disabled');
            return;
        }

        // Get the response output
        $response_body = $this->response->getOutput();
        if (empty($response_body)) {
            $this->log->write('CodGuard [DEBUG]: No response body');
            return;
        }

        $json_data = json_decode($response_body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->log->write('CodGuard [ERROR]: Invalid JSON in response');
            return;
        }

        // Check if payment method was successfully set (no existing error)
        // We need to validate BEFORE the payment is confirmed as OK
        if (isset($json_data['success'])) {
            $this->log->write('CodGuard [DEBUG]: Payment method successfully selected, checking if it is COD');

            // Get selected payment method from POST
            $payment_code = $this->request->post['payment_method'] ?? '';
            if (empty($payment_code)) {
                $this->log->write('CodGuard [DEBUG]: No payment method in POST');
                return;
            }

            $this->log->write('CodGuard [DEBUG]: Payment method: ' . $payment_code);

            // Check if it's a COD method
            $cod_methods = $this->config->get('module_codguard_cod_methods');
            $is_cod = false;

            if ($cod_methods) {
                foreach ($cod_methods as $method) {
                    if (strpos($payment_code, $method) !== false) {
                        $is_cod = true;
                        $this->log->write('CodGuard [DEBUG]: Pattern match:  . \$payment_code .  contains  . \$method . ');
                        break;
                    }
                }
            }

            if (!$is_cod) {
                $this->log->write('CodGuard [INFO]: Not a COD payment method');
                return;
            }

            $this->log->write('CodGuard [INFO]: COD payment detected, validating customer rating');

            // Get customer email
            $email = '';
            if (isset($this->session->data['customer']['email'])) {
                $email = $this->session->data['customer']['email'];
            } elseif (isset($this->session->data['guest']['email'])) {
                $email = $this->session->data['guest']['email'];
            } elseif ($this->customer->isLogged()) {
                $email = $this->customer->getEmail();
            }

            if (empty($email)) {
                $this->log->write('CodGuard [INFO]: No email found - allowing');
                return;
            }

            $this->log->write('CodGuard [INFO]: Validating email: ' . $email);

            $this->load->model('extension/codguard/fraud/codguard');
            $this->load->language('extension/codguard/fraud/codguard');

            // Get customer rating from API
            $rating = $this->model_extension_codguard_fraud_codguard->getCustomerRating($email);

            // If API failed, allow (fail-open)
            if ($rating === null) {
                $this->log->write('CodGuard [WARNING]: API failed, allowing payment method (fail-open)');
                return;
            }

            // Compare to tolerance
            $tolerance = (float)$this->config->get('module_codguard_rating_tolerance') / 100;
            $this->log->write('CodGuard [DEBUG]: Rating: ' . $rating . ', Tolerance: ' . $tolerance);

            if ($rating < $tolerance) {
                // Block COD payment method
                $this->model_extension_codguard_fraud_codguard->logBlockEvent(
                    $email,
                    $rating,
                    $this->request->server['REMOTE_ADDR'] ?? ''
                );

                $this->log->write('CodGuard [WARNING]: BLOCKING COD - Rating: ' . $rating . ' < Tolerance: ' . $tolerance);

                // Get custom error message
                $error_message = $this->config->get('module_codguard_rejection_message');
                if (empty($error_message)) {
                    $error_message = 'Unfortunately, we cannot offer Cash on Delivery for this order. Please choose a different payment method.';
                }

                // Replace success with error
                unset($json_data['success']);
                $json_data['error'] = $error_message;

                // Update the response
                $this->response->setOutput(json_encode($json_data));
                $this->log->write('CodGuard [INFO]: Response updated with error message');
            } else {
                $this->log->write('CodGuard [INFO]: ALLOWING COD - Rating: ' . $rating . ' >= Tolerance: ' . $tolerance);
            }
        }
    }
}
