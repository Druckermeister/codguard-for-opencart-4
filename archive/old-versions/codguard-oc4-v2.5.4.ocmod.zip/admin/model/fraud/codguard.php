<?php
/**
 * CodGuard for OpenCart 4.x - Admin Model
 *
 * @package    CodGuard
 * @author     CodGuard
 * @copyright  2025 CodGuard
 * @license    GPL v2 or later
 * @version    2.4.1
 */

namespace Opencart\Admin\Model\Extension\Codguard\Fraud;

class Codguard extends \Opencart\System\Engine\Model {

    /**
     * Install extension
     */
    public function install(): void {
        // Create block events table
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "codguard_block_events` (
                `event_id` int(11) NOT NULL AUTO_INCREMENT,
                `email` varchar(255) NOT NULL,
                `rating` decimal(5,4) NOT NULL,
                `timestamp` int(11) NOT NULL,
                `ip_address` varchar(45) DEFAULT NULL,
                PRIMARY KEY (`event_id`),
                KEY `timestamp` (`timestamp`),
                KEY `email` (`email`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
        ");

        // Create order queue table for bundled sync
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "codguard_order_queue` (
                `queue_id` int(11) NOT NULL AUTO_INCREMENT,
                `order_id` int(11) NOT NULL,
                `order_data` text NOT NULL,
                `created_at` datetime NOT NULL,
                `sent_at` datetime DEFAULT NULL,
                `status` enum('pending','sent','failed') DEFAULT 'pending',
                PRIMARY KEY (`queue_id`),
                UNIQUE KEY `order_id` (`order_id`),
                KEY `status` (`status`),
                KEY `created_at` (`created_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
        ");

        // Create settings table to persist configuration even after uninstall
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "codguard_settings` (
                `setting_id` int(11) NOT NULL AUTO_INCREMENT,
                `key` varchar(64) NOT NULL,
                `value` text NOT NULL,
                `serialized` tinyint(1) NOT NULL DEFAULT 0,
                PRIMARY KEY (`setting_id`),
                UNIQUE KEY `key` (`key`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
        ");

        // Migrate existing settings from oc_setting to codguard_settings
        $this->migrateSettings();

        // Register event handlers
        $this->load->model('setting/event');

        // MAIN EVENT: Filter payment methods when they're loaded
        // This is the primary mechanism - it prevents COD from even appearing for low-rated customers
        $this->model_setting_event->addEvent([
            'code' => 'codguard_filter_payment_methods',
            'description' => 'CodGuard filter payment methods based on customer rating',
            'trigger' => 'catalog/model/checkout/payment_method/getMethods/after',
            'action' => 'extension/codguard/fraud/codguard|filterPaymentMethods',
            'status' => 1,
            'sort_order' => 0
        ]);

        // Payment method controller validation (try to catch AJAX save) - BACKUP
        $this->model_setting_event->addEvent([
            'code' => 'codguard_payment_method_save',
            'description' => 'CodGuard payment method validation',
            'trigger' => 'catalog/controller/checkout/payment_method.save/before',
            'action' => 'extension/codguard/fraud/codguard.validatePaymentMethodController',
            'status' => 1,
            'sort_order' => 0
        ]);

        // Also try model-level event - BACKUP
        $this->model_setting_event->addEvent([
            'code' => 'codguard_payment_method_model',
            'description' => 'CodGuard payment method model validation',
            'trigger' => 'catalog/model/checkout/payment_method/setPaymentMethod/before',
            'action' => 'extension/codguard/fraud/codguard.validatePaymentMethod',
            'status' => 1,
            'sort_order' => 0
        ]);

        // Order status change event
        $this->model_setting_event->addEvent([
            'code' => 'codguard_order_status_change',
            'description' => 'CodGuard order status change handler',
            'trigger' => 'catalog/model/checkout/order/addHistory/after',
            'action' => 'extension/codguard/fraud/codguard.eventOrderStatusChange',
            'status' => 1,
            'sort_order' => 0
        ]);

        // Checkout validation event (server-side validation before order confirmation)
        // Note: We use catalog/model/checkout/order/addOrder/before which is called
        // right before the order is created, ensuring payment method is available
        $this->model_setting_event->addEvent([
            'code' => 'codguard_checkout_validation',
            'description' => 'CodGuard checkout validation before order creation',
            'trigger' => 'catalog/model/checkout/order/addOrder/before',
            'action' => 'extension/codguard/fraud/codguard.validateCheckout',
            'status' => 1,
            'sort_order' => 0
        ]);

        // JavaScript injection event (adds CodGuard JS to checkout pages)
        $this->model_setting_event->addEvent([
            'code' => 'codguard_add_javascript',
            'description' => 'CodGuard JavaScript injection for checkout pages',
            'trigger' => 'catalog/view/*/before',
            'action' => 'extension/codguard/fraud/codguard.addJavaScript',
            'status' => 1,
            'sort_order' => 0
        ]);

        // Also try catalog/controller/checkout/confirm/before as fallback
        $this->model_setting_event->addEvent([
            'code' => 'codguard_checkout_confirm',
            'description' => 'CodGuard checkout confirm handler (fallback)',
            'trigger' => 'catalog/controller/checkout/confirm/before',
            'action' => 'extension/codguard/fraud/codguard.validateCheckoutConfirm',
            'status' => 1,
            'sort_order' => 0
        ]);

        // Also catch the success page (order has been created, but we can still validate)
        $this->model_setting_event->addEvent([
            'code' => 'codguard_checkout_success',
            'description' => 'CodGuard checkout success handler (order created)',
            'trigger' => 'catalog/controller/checkout/success/before',
            'action' => 'extension/codguard/fraud/codguard.validateAfterOrder',
            'status' => 1,
            'sort_order' => 0
        ]);

        // Log installation
        $this->log->write('CodGuard extension installed successfully - 8 events registered (including payment method filter)');
    }

    /**
     * Uninstall extension
     */
    public function uninstall(): void {
        // Remove event handlers
        $this->load->model('setting/event');
        $this->model_setting_event->deleteEventByCode('codguard_filter_payment_methods');
        $this->model_setting_event->deleteEventByCode('codguard_payment_method_save');
        $this->model_setting_event->deleteEventByCode('codguard_payment_method_model');
        $this->model_setting_event->deleteEventByCode('codguard_order_status_change');
        $this->model_setting_event->deleteEventByCode('codguard_checkout_validation');
        $this->model_setting_event->deleteEventByCode('codguard_add_javascript');
        $this->model_setting_event->deleteEventByCode('codguard_checkout_confirm');
        $this->model_setting_event->deleteEventByCode('codguard_checkout_success');

        // Note: We don't drop tables to preserve data
        // Drop tables manually if needed:
        // DROP TABLE IF EXISTS `" . DB_PREFIX . "codguard_block_events`;
        // DROP TABLE IF EXISTS `" . DB_PREFIX . "codguard_order_queue`;

        $this->log->write('CodGuard extension uninstalled');
    }

    /**
     * Get statistics for different time periods
     */
    public function getStatistics(): array {
        $stats = array(
            'today' => 0,
            'week' => 0,
            'month' => 0,
            'all' => 0
        );

        $today_start = strtotime('today');
        $week_start = strtotime('-7 days');
        $month_start = strtotime('-30 days');

        // Today
        $query = $this->db->query("
            SELECT COUNT(*) as total
            FROM `" . DB_PREFIX . "codguard_block_events`
            WHERE timestamp >= " . (int)$today_start . "
        ");
        $stats['today'] = $query->row['total'];

        // Last 7 days
        $query = $this->db->query("
            SELECT COUNT(*) as total
            FROM `" . DB_PREFIX . "codguard_block_events`
            WHERE timestamp >= " . (int)$week_start . "
        ");
        $stats['week'] = $query->row['total'];

        // Last 30 days
        $query = $this->db->query("
            SELECT COUNT(*) as total
            FROM `" . DB_PREFIX . "codguard_block_events`
            WHERE timestamp >= " . (int)$month_start . "
        ");
        $stats['month'] = $query->row['total'];

        // All time
        $query = $this->db->query("
            SELECT COUNT(*) as total
            FROM `" . DB_PREFIX . "codguard_block_events`
        ");
        $stats['all'] = $query->row['total'];

        return $stats;
    }

    /**
     * Get recent block events
     */
    public function getRecentBlocks(int $limit = 10): array {
        $query = $this->db->query("
            SELECT email, rating, timestamp, ip_address
            FROM `" . DB_PREFIX . "codguard_block_events`
            ORDER BY timestamp DESC
            LIMIT " . (int)$limit . "
        ");

        return $query->rows;
    }

    /**
     * Add block event
     */
    public function addBlockEvent(string $email, float $rating, string $ip_address = ''): void {
        $this->db->query("
            INSERT INTO `" . DB_PREFIX . "codguard_block_events`
            SET email = '" . $this->db->escape($email) . "',
                rating = '" . (float)$rating . "',
                timestamp = " . time() . ",
                ip_address = '" . $this->db->escape($ip_address) . "'
        ");
    }

    /**
     * Clean old block events (older than 90 days)
     */
    public function cleanOldBlockEvents(): void {
        $ninety_days_ago = strtotime('-90 days');

        $this->db->query("
            DELETE FROM `" . DB_PREFIX . "codguard_block_events`
            WHERE timestamp < " . (int)$ninety_days_ago . "
        ");
    }

    /**
     * Add order to queue
     */
    public function addOrderToQueue(int $order_id, array $order_data): void {
        $this->db->query("
            INSERT INTO `" . DB_PREFIX . "codguard_order_queue`
            SET order_id = " . (int)$order_id . ",
                order_data = '" . $this->db->escape(json_encode($order_data)) . "',
                created_at = NOW(),
                status = 'pending'
            ON DUPLICATE KEY UPDATE
                order_data = '" . $this->db->escape(json_encode($order_data)) . "',
                created_at = NOW(),
                status = 'pending'
        ");
    }

    /**
     * Get pending orders from queue
     */
    public function getPendingOrders(): array {
        $query = $this->db->query("
            SELECT queue_id, order_id, order_data
            FROM `" . DB_PREFIX . "codguard_order_queue`
            WHERE status = 'pending'
            AND created_at <= DATE_SUB(NOW(), INTERVAL 1 HOUR)
            ORDER BY created_at ASC
        ");

        $orders = array();
        foreach ($query->rows as $row) {
            $orders[] = array(
                'queue_id' => $row['queue_id'],
                'order_id' => $row['order_id'],
                'data' => json_decode($row['order_data'], true)
            );
        }

        return $orders;
    }

    /**
     * Mark orders as sent
     */
    public function markOrdersAsSent(array $queue_ids): void {
        if (empty($queue_ids)) {
            return;
        }

        $this->db->query("
            UPDATE `" . DB_PREFIX . "codguard_order_queue`
            SET status = 'sent',
                sent_at = NOW()
            WHERE queue_id IN (" . implode(',', array_map('intval', $queue_ids)) . ")
        ");
    }

    /**
     * Mark orders as failed
     */
    public function markOrdersAsFailed(array $queue_ids): void {
        if (empty($queue_ids)) {
            return;
        }

        $this->db->query("
            UPDATE `" . DB_PREFIX . "codguard_order_queue`
            SET status = 'failed'
            WHERE queue_id IN (" . implode(',', array_map('intval', $queue_ids)) . ")
        ");
    }

    /**
     * Clean old sent orders (older than 7 days)
     */
    public function cleanOldQueueItems(): void {
        $this->db->query("
            DELETE FROM `" . DB_PREFIX . "codguard_order_queue`
            WHERE status = 'sent'
            AND sent_at < DATE_SUB(NOW(), INTERVAL 7 DAY)
        ");
    }

    /**
     * Get queue statistics
     */
    public function getQueueStatistics(): array {
        $stats = array(
            'pending' => 0,
            'sent' => 0,
            'failed' => 0
        );

        $query = $this->db->query("
            SELECT status, COUNT(*) as total
            FROM `" . DB_PREFIX . "codguard_order_queue`
            GROUP BY status
        ");

        foreach ($query->rows as $row) {
            $stats[$row['status']] = $row['total'];
        }

        return $stats;
    }

    /**
     * Migrate settings from oc_setting to codguard_settings table
     */
    private function migrateSettings(): void {
        $keys = array(
            'module_codguard_status',
            'module_codguard_shop_id',
            'module_codguard_public_key',
            'module_codguard_private_key',
            'module_codguard_rating_tolerance',
            'module_codguard_rejection_message',
            'module_codguard_good_status',
            'module_codguard_refused_status',
            'module_codguard_cod_methods'
        );

        foreach ($keys as $key) {
            $value = $this->config->get($key);
            if ($value !== null) {
                $this->saveSetting($key, $value);
            }
        }
    }

    /**
     * Save setting to codguard_settings table
     */
    public function saveSetting(string $key, $value): void {
        $serialized = 0;
        if (is_array($value) || is_object($value)) {
            $value = serialize($value);
            $serialized = 1;
        }

        $this->db->query("
            INSERT INTO `" . DB_PREFIX . "codguard_settings`
            SET `key` = '" . $this->db->escape($key) . "',
                `value` = '" . $this->db->escape($value) . "',
                `serialized` = " . (int)$serialized . "
            ON DUPLICATE KEY UPDATE
                `value` = '" . $this->db->escape($value) . "',
                `serialized` = " . (int)$serialized . "
        ");
    }

    /**
     * Load setting from codguard_settings table
     */
    public function loadSetting(string $key) {
        $query = $this->db->query("
            SELECT `value`, `serialized`
            FROM `" . DB_PREFIX . "codguard_settings`
            WHERE `key` = '" . $this->db->escape($key) . "'
        ");

        if ($query->num_rows) {
            $value = $query->row['value'];
            if ($query->row['serialized']) {
                $value = unserialize($value);
            }
            return $value;
        }

        return null;
    }

    /**
     * Load all settings from codguard_settings table
     */
    public function loadAllSettings(): array {
        $settings = array();

        $query = $this->db->query("
            SELECT `key`, `value`, `serialized`
            FROM `" . DB_PREFIX . "codguard_settings`
        ");

        foreach ($query->rows as $row) {
            $value = $row['value'];
            if ($row['serialized']) {
                $value = unserialize($value);
            }
            $settings[$row['key']] = $value;
        }

        return $settings;
    }
}
